/// <reference path="path.d.ts" />
/// <reference path="Buffer.d.ts" />
