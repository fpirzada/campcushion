define('EntryPointPathShim', ['DependencyPath'], function() {});
