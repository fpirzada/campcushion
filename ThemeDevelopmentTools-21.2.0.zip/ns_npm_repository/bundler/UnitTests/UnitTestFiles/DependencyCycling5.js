define('DependencyCycling5', ['DependencyCycling4'], function() {});
