define('SC.Models.Init', ['SuiteLogs'], function(SuiteLogs) {});
