define('EntryPointMap1', ['DependencyMap1'], function() {});
