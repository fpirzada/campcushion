define('EntryPointEmptyDefine2', ['EmptyDefineWithFunction'], function() {});
