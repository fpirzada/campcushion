define('DependencyMap3', function() {});
