# WIP / TODO

 * sass
 * variables
 * classes
 * best practices - use @xtend - etc....
 * compatibiltiy of variables and classes so your extension looks nice and works in any theme
 * declare variables for theme-customizer in SMT